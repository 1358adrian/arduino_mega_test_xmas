// Can be moved in header file i.e notes.h
#define ARRAY_LEN(array) (sizeof(array) / sizeof(array[0]))
#define A5 880
#define Db5 622
#define E5 659
#define Fb5 740
#define A4 440
#define Gb5 831
#define B5 988
#define B4 494
#define Cb5 554

#define A5 880
#define Ab5 932
#define C6 1047
#define D6 1175
#define E6 1319
#define F6 1397
#define F5 698
#define G5 784
#define E5 659
#define G6 1568
#define A6 1760
#define Fb6 1480
#define C5 523
#define D5 587
#define B5 988
#define B6 1976
#define C7 2093
#define Ab6 1865