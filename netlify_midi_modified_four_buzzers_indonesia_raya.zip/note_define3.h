// Can be moved in header file i.e notes.h
#define ARRAY_LEN3(array3) (sizeof(array3) / sizeof(array3[0]))
#define Cb4 277
#define Fb4 370
#define Ab3 233
#define B3 247
#define Db4 311
#define F4 349
#define Gb4 415
#define Ab4 466
#define Cb5 554
#define B4 494