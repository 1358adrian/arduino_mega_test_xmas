// Can be moved in header file i.e notes.h
#define ARRAY_LEN(array) (sizeof(array) / sizeof(array[0]))
#define Ab4 466
#define B4 494
#define Cb5 554
#define Ab5 932
#define Gb5 831
#define Fb5 740
#define Db5 622
#define Gb4 415
#define F5 698
#define B5 988
#define Cb6 1109
#define Db6 1245