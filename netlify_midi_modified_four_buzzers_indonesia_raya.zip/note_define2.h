#define ARRAY_LEN2(array2) (sizeof(array2) / sizeof(array2[0]))
#define Fb4 370
#define Gb4 415
#define Ab4 466
#define Cb5 554
#define B4 494
#define F4 349
#define Db4 311
#define D5 587
#define Db5 622
#define Fb5 740
#define F5 698