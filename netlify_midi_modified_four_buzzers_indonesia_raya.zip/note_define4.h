#define ARRAY_LEN4(array4) (sizeof(array4) / sizeof(array4[0]))
#define Fb2 92
#define B2 123
#define Ab2 117
#define Gb2 104
#define Cb2 69
#define Ab1 58
#define B1 62
#define Db2 78
#define Gb1 52
#define F2 87
#define Fb1 46